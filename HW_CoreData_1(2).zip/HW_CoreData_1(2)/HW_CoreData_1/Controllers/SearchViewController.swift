//
//  SearchViewController.swift
//  HW_CoreData_1
//
//  Created by Mykhailo Romanovskyi on 15.09.2020.
//  Copyright © 2020 Mykhailo Romanovskyi. All rights reserved.
//
// MARK: Protocol
protocol SearchDelegate: class {
    func viewController(_ viewController: SearchViewController, didPassedData predicate: NSCompoundPredicate)
}

import UIKit

class SearchViewController: UIViewController {
    
    @IBOutlet weak var bgView: UIView!
    @IBOutlet weak var nameForSearch: UITextField!
    @IBOutlet weak var age: UITextField!
    @IBOutlet weak var segmentedControl: UISegmentedControl!
    @IBOutlet weak var positionButton: UIButton!
    @IBOutlet weak var teamButton: UIButton!
    
    @IBOutlet weak var pickersView: UIView!
    @IBOutlet weak var positionPicker: UIPickerView!
    @IBOutlet weak var teamPicker: UIPickerView!
    
    weak var delegate: SearchDelegate?
    private var selectedTeam = ""
    private var selectedPosition = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        pickersView.isHidden = true
        positionPicker.delegate = self
        positionPicker.dataSource = self
        teamPicker.delegate = self
        teamPicker.dataSource = self
        
        let closeTap = UITapGestureRecognizer(target: self, action: #selector(closeTapGesture(_:)))
        bgView.addGestureRecognizer(closeTap)
        
        nameForSearch.inputAccessoryView = createToolBar()
        age.inputAccessoryView = createToolBar()
    }
    
    @IBAction func positionButtonPressed(_ sender: Any) {
        pickersView.isHidden = false
        teamPicker.isHidden = true
    }
    
    @IBAction func teamButtonPressed(_ sender: Any) {
        pickersView.isHidden = false
        positionPicker.isHidden = true
    }
    
    @IBAction func startSearchPressed(_ sender: Any) {
        let compaundPredicate = makeCompaundePredicete(name: nameForSearch.text!, age: age.text!, position: selectedPosition, team: selectedTeam )
        delegate?.viewController(self, didPassedData: compaundPredicate)
        dismiss(animated: true, completion: nil)
    }
    
    @IBAction func resetPresed(_ sender: Any) {
        delegate?.viewController(self, didPassedData: NSCompoundPredicate(andPredicateWithSubpredicates: []))
        dismiss(animated: true, completion: nil)
    }
    
    private func createToolBar() -> UIToolbar {
        let toolBar = UIToolbar()
        toolBar.sizeToFit()
        
        let doneButton = UIBarButtonItem(title: "Done", style: .done, target: self, action: #selector(keyboardDismiss))
        toolBar.setItems([doneButton], animated: true)
        toolBar.isUserInteractionEnabled = true
        return toolBar
    }
    
    private func makeCompaundePredicete(name: String, age: String, position: String, team: String) -> NSCompoundPredicate {
        var predicates = [NSPredicate]()
        
        if !name.isEmpty {
            let namePredicate = NSPredicate(format: "fullName CONTAINS[cd] '\(name)'")
            predicates.append(namePredicate)
        }
        
        if !age.isEmpty {
            let selectedSegmentControl = priceSearchCondition(index: segmentedControl.selectedSegmentIndex)
            let agePredicate = NSPredicate(format: "age \(selectedSegmentControl) '\(age)'")
            predicates.append(agePredicate)
        }
        
        if !position.isEmpty {
            let positionPredicate = NSPredicate(format: "position CONTAINS[cd] '\(position)'")
            predicates.append(positionPredicate)
        }
        
        if !team.isEmpty {
            let teamPredicate = NSPredicate(format: "club.name CONTAINS[cd] '\(team)'")
            predicates.append(teamPredicate)
        }
        
        print(predicates)
        return NSCompoundPredicate(andPredicateWithSubpredicates: predicates)
    }
    
    private func priceSearchCondition(index: Int) -> String {
        var condition: String!
        
        switch index {
        case 0: condition = ">="
        case 1: condition = "="
        case 2: condition = "<="
        default: break
        }
        return condition
    }
    
    @objc func closeTapGesture (_ recognizer: UITapGestureRecognizer) {
        dismiss(animated: true, completion: nil)
    }
    
    @objc private func keyboardDismiss() {
        view.endEditing(true)
    }
}

extension SearchViewController: UIPickerViewDelegate, UIPickerViewDataSource {
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        pickerView.tag == 0 ? PlayerViewController.Position.positions.count : PlayerViewController.Team.teams.count
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        pickerView.tag == 0 ? PlayerViewController.Position.positions[row] : PlayerViewController.Team.teams[row]
    }
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        if pickerView.tag == 0 {
            positionButton.setTitle(PlayerViewController.Position.positions[row], for: .normal)
            selectedPosition = PlayerViewController.Position.positions[row]
            pickersView.isHidden = true
            teamPicker.isHidden = false
        } else {
            teamButton.setTitle(PlayerViewController.Team.teams[row], for: .normal)
            selectedTeam = PlayerViewController.Team.teams[row]
            pickersView.isHidden = true
            positionPicker.isHidden = false
        }
    }
}
