//
//  MainViewController.swift
//  HW_CoreData_1
//
//  Created by Mykhailo Romanovskyi on 18.08.2020.
//  Copyright © 2020 Mykhailo Romanovskyi. All rights reserved.
//

import UIKit
import CoreData

class MainViewController: UIViewController {
    
    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var inPLAYSsegmentedControll: UISegmentedControl!
    
    var dataManager: CoreDataManager!
    private var items = [Player]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        tableView.delegate = self
        tableView.dataSource = self
        navigationItem.title = "Team Manager"
        navigationItem.rightBarButtonItem = UIBarButtonItem(
            barButtonSystemItem: .add,
            target: self,
            action: #selector(addPlayer)
        )
        navigationItem.leftBarButtonItem = UIBarButtonItem(
            barButtonSystemItem: .search,
            target: self,
            action: #selector(filterPlayers))
        
        //MARK: Использовать только один раз, желательно, иначе будет каждый раз добавляться новые игроки.
        //fillDataModel()
    }
    
    @IBAction func inPlaySegmentedControllPressed(_ sender: Any) {
        items.removeAll()
        fetchData()
        tableView.reloadData()
    }
    
    @objc func addPlayer() {
        let storyboard = UIStoryboard(name: "PlayerViewController", bundle: Bundle.main)
        guard let plaeyVC = storyboard.instantiateViewController(identifier: "PlayerViewController") as? PlayerViewController else {
            return
        }
        plaeyVC.dataManager = dataManager
        navigationController?.pushViewController(plaeyVC, animated: true )
    }
    
    @objc func filterPlayers() {
        let searchVC = SearchViewController()
        searchVC.delegate = self
        searchVC.modalTransitionStyle = .crossDissolve
        searchVC.modalPresentationStyle = .overCurrentContext
        print("Hello")
        present(searchVC, animated: true)
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(true)
        fetchData()
        tableView.reloadData()
    }
    
    private func fetchData(predicate: NSCompoundPredicate? = nil) {
        
        let fetxhedItems = dataManager.fetchData(for: Player.self, predicate: predicate)
        
        switch inPLAYSsegmentedControll.selectedSegmentIndex {
        case 0:
            items = fetxhedItems
        case 1:
            items = fetxhedItems.filter({$0.inPLay == "In Play"})
        case 2:
            items = fetxhedItems.filter({$0.inPLay == "Bench"})
        default:
            break
        }
        
        if items.count > 0 {
            tableView.isHidden = false
        } else {
            tableView.isHidden = true
        }
    }
}

extension MainViewController: UITableViewDelegate {
    
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            self.dataManager.delete(object: self.items[indexPath.row])
            self.fetchData()
            tableView.deleteRows(at: [indexPath], with: .automatic)
        }
    }
}

extension MainViewController: UITableViewDataSource {
    
    func numberOfSections(in tableView: UITableView) -> Int {
        Positions.positions.count
    }
    
    func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        Positions.positions[section]
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        items.filter({$0.position == Positions.positions[section]}).count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as! ItemTableViewCell
        cell.configurator(with: items.filter({$0.position == Positions.positions[indexPath.section]})[indexPath.row])
        return cell
    }
}

extension MainViewController: SearchDelegate {
    func viewController(_ viewController: SearchViewController, didPassedData predicate: NSCompoundPredicate) {
        fetchData(predicate: predicate)
        tableView.reloadData()
        print("Search Delegat")
    }    
}
