//
//  AppDelegate.swift
//  HW_CoreData_1
//
//  Created by Mykhailo Romanovskyi on 18.08.2020.
//  Copyright © 2020 Mykhailo Romanovskyi. All rights reserved.
//

import UIKit

@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate {

var window: UIWindow?

    let dataManager = CoreDataManager(modelName: "FootboolManager")
    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
        
        let storyboard = UIStoryboard(name: "MainViewController", bundle: Bundle.main)

        guard let mainVC = storyboard.instantiateViewController(identifier: "MainViewController") as? MainViewController else {
            return false
        }
        mainVC.dataManager = dataManager
        let navMainVC = UINavigationController(rootViewController: mainVC)        
        window = UIWindow(frame: UIScreen.main.bounds)
        window?.rootViewController = navMainVC
        window?.makeKeyAndVisible()
        return true
    }
}

