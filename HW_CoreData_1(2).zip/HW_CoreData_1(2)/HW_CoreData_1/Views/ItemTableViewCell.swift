//
//  ItemTableViewCell.swift
//  HW_CoreData_1
//
//  Created by Mykhailo Romanovskyi on 18.08.2020.
//  Copyright © 2020 Mykhailo Romanovskyi. All rights reserved.
//

import UIKit

class ItemTableViewCell: UITableViewCell {
    @IBOutlet weak var inPlay: UILabel!
    @IBOutlet weak var playerNumber: UILabel!
    @IBOutlet weak var fullName: UILabel!
    @IBOutlet weak var avatar: UIImageView!
    @IBOutlet weak var teamName: UILabel!
    @IBOutlet weak var nationality: UILabel!
    @IBOutlet weak var position: UILabel!
    @IBOutlet weak var age: UILabel!
    
    func configurator(with item: Player?) {
        guard let item = item else { return }
        inPlay.text = item.inPLay
        playerNumber.text = item.playerNumber
        fullName.text = item.fullName
        avatar.image = item.image?.image as? UIImage
        teamName.text = item.club?.name
        nationality.text = item.nationality
        position.text = item.position
        age.text = String(item.age)
    }
}
